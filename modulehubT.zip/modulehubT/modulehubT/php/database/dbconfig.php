<?php
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "pumhv3";

$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);

if (!$conn) {
    echo"Connection failed: " . mysqli_connect_error();
}
?>
