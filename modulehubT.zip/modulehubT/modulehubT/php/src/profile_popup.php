<div id="profilePopup" class="popup">
    <div class="popup-content">
        <a href="#" class="close">&times;</a>
        <h2>PROFILE</h2>
        <p><strong>Name:</strong> Tinte, Bien Mari P.</p>
        <p><strong>Gender:</strong> Male</p>
        <p><strong>ID #:</strong> 123-456-7890</p>
        <p><strong>Contact Number:</strong> 098765432112</p>
        <p><strong>Email:</strong> example@phinmaed.com</p>
        <p><strong>Course & Block:</strong> BSIT2-01</p>
        <p><strong>Department:</strong> CITE Department</p>
    </div>
</div>