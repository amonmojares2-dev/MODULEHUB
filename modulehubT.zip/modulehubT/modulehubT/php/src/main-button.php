<?php include 'REQUEST_POPUP.php'; ?>
<?php include 'profile_popup.php'; ?>
<main class="main-buttons">
        <div class="container">
            <div class="button-section">
                <div class="buton-container">
                <a href="#popupRequest"><button>Request Modules</button></a>
                    <a href="#popup2"><button>My Requests</button></a>
                    <a href="#profilePopup"><button>My Profile</button></a>
                </div>
            </div>
        </div>
    </main>