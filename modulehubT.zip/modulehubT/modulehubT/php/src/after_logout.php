<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Logging out...</title>
  <meta http-equiv="refresh" content="2;url=login.php">
  <link rel="stylesheet" href="../../css/logout.css">
</head>
<body>
  <div class="popup" style="display:flex;justify-content:center;align-items:center;height:100vh;">
    <div class="popup-content">
      <h2>Logging out...</h2>
    </div>
  </div>
</body>
</html>
