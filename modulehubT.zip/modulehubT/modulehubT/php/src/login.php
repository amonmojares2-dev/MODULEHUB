<?php
session_start();
require_once "../database/dbconfig.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    
    // Check admin table
    $sql_admin = "SELECT ADMIN_ID, ADMIN_NAME, ADMIN_PASSWORD, ADMIN_EMAIL, ADMIN_POSITION FROM admintb WHERE ADMIN_ID = ?";
    $stmt_admin = mysqli_prepare($conn, $sql_admin);
    mysqli_stmt_bind_param($stmt_admin, "s", $username);

    if (mysqli_stmt_execute($stmt_admin)) {
        mysqli_stmt_store_result($stmt_admin);

        if (mysqli_stmt_num_rows($stmt_admin) == 1) {
            mysqli_stmt_bind_result($stmt_admin, $admin_id, $admin_name, $admin_password, $admin_email, $admin_position);
            mysqli_stmt_fetch($stmt_admin);

            if (password_verify($password, $admin_password)) {
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $admin_id;
                $_SESSION["username"] = $username;
                $_SESSION["name"] = $admin_name;
                $_SESSION["role"] = $admin_position;

                header("Location: admin.php");
                exit;
            } else {
                echo "Invalid password.";
                exit;
            }
        }
        mysqli_stmt_close($stmt_admin);
    }

    // Check students table
    $sql = "SELECT S_ID, F_NAME, M_I, L_NAME, S_PASSWORD, EMAIL, S_NUMBER, COURSE_ID, YEAR_LEVEL, ROLE FROM students WHERE S_ID = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);

    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) == 1) {
            mysqli_stmt_bind_result($stmt, $id, $fname, $mi, $lname, $hashed_password, $email, $s_number, $course_id, $year_level, $role);
            mysqli_stmt_fetch($stmt);

            if (password_verify($password, $hashed_password)) {
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $id;
                $_SESSION["username"] = $username;
                $_SESSION["name"] = $fname . ' ' . $mi . '. ' . $lname;
                $_SESSION["role"] = $role;

                header("Location: student.php");
                exit;
            } else {
                echo "Invalid password.";
                exit;
            }
        } else {
            echo "No account found with that ID.";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Oops! Something went wrong.";
    }
}
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHINMA UPang Module Hub</title>
    <link rel="stylesheet" href="../../css/styles.css">
</head>
<body>
<div class="container">
    <div class="left">
        <img src="../../.asset/image/upang1.png" alt="DocQueue Logo" class="app-logo">
        <h1>PHINMA UPang Module Hub</h1>
        <p>Manage your documents seamlessly</p>
    </div>
    <div class="right">
        <img src="../../.asset/image/upang1.png" alt="School Logo" class="school-logo">
    
    <div class="form-container">
            <!-- Only one form, posting back to THIS FILE -->
            <form action="login.php" method="post">
                <h1>Login</h1>
                <input type="text" name="username" placeholder="Enter Username" required>
                <input type="password" name="password" placeholder="Enter Password" required>

                <button type="submit">Login</button>
            </form>
        </div>

        <footer>
            <p>&copy; 2024 PHINMA UPang Module Hub. All rights reserved.</p>
        </footer>
    </div>
</div>
</body>
</html>
