<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THANKYOU!, GOODBYE.</title>

</head>
<body>
    <div class="thankyou-container">
        <h1>Thank you for using PHINMA UPang Module Hub!</h1>
        <p>You have been successfully logged out.</p>
        <a href="login.php" class="login-link">Log In Again</a>
    </div>
</body>
</html>
