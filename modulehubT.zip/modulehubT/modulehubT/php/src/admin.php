<?php
    session_start();

    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("Location: login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link rel="stylesheet" href="../../css/styles.css">
    <link rel="stylesheet" href="../../css/SIDEBAR.css"/>
    <link rel="stylesheet" href="../../css/logout.css"/>
    <link rel="stylesheet" href="../../css/3main.css"/>
    <link rel="stylesheet" href="../../css/datetime.css"/>
</head>
<body>
    
<?php include 'sidebar.php';?>
 

    <!-- video-bg should be a sibling of .main (behind it) -->
    <div class="video-bg" aria-hidden="true">
        <video autoplay muted loop playsinline id="bg-video" preload="auto">
            <source src="../../.asset/image/UPang.webm" type="video/webm">
            Your browser does not support the video tag.
        </video>
    </div>
</body>
</html>
<?php include 'REQUEST_POPUP.php'; ?> 
<?php include 'main-button.php'; ?>
<?php include 'logout.php';?>
