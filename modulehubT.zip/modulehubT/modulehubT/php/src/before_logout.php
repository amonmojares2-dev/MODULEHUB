<div id="logout-popup" class="popup">
  <div class="popup-content">
    <h2>Are you sure you want to Log Out?</h2>
    <div class="button-row">
      <!-- Yes → go to loggingout.php -->
      <a href="after_logout.php" class="btn yes-btn">Yes</a>
      <!-- No → close -->
      <a href="#" class="btn no-btn">No</a>
    </div>
  </div>
</div>
