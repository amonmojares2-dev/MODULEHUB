<div class="faq-right">

<!-- Popup 1 -->
<div id="popup1" class="popup">
    <div class="popup-content">
        <a href="#" class="close">&times;</a>
        <p>To request a module, go to the Request Modules section, fill out your subject details, and submit the form for approval.</p>
    </div>
</div>

<!-- Popup 2 -->
<div id="popup2" class="popup">
    <div class="popup-content">
        <a href="#" class="close">&times;</a>
        <p>If you miss your appointment, you must rebook another schedule through the Request Module page or contact your department representative.</p>
    </div>
</div>

<!-- Popup 3 -->
<div id="popup3" class="popup">
    <div class="popup-content">
        <a href="#" class="close">&times;</a>
        <p>Once your request is approved, check the appointment date and time in your notification. Bring your Request ID and any required documents when you visit the module distribution area. Claim your module within the given duration to avoid expiration.</p>
    </div>
</div>
</div>
</div>