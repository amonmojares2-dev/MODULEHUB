<div class="sidebar">
    <!-- Upper section -->
    <div class="upper">
    <img src="" alt="Menu" class="sidebar-img">
    <a href="#notif_Popup.php"><img src="../../.asset/image/notif.png" alt="Notification" class="sidebar-img"></a>
    </div>

    <!-- Lower section -->
    <div class="lower">
    <a href="faqs.php"><img src="../../.asset/image/faqs_.png" alt="FAQs" class="sidebar-img"></a>
    <a href="info.php"><img src="../../.asset/image/info.png" alt="Info" class="sidebar-img"></a>
    <a href="#logout-popup" class="logout-btn"><img src="../../.asset/image/LOGOUT.png" alt="Logout" class="sidebar-img"></a> 
    </div>
</div>
<?php include 'before_logout.php';?>
<?php include 'REQUEST_POPUP.php';?>
<?php include 'profile_popup.php'; ?>
<?php include 'faqs.php';?>

    <div class="video-bg" aria-hidden="true">
        <video autoplay muted loop playsinline id="bg-video" preload="auto">
            <source src="../../.asset/image/UPang.webm" type="video/webm">
        </video>
    </div>