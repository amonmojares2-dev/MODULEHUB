<link rel="stylesheet" href="notif.css">
<div class="main-content">
    <div class="container">
        <h1>Notifications</h1>
    </div>
</div>
