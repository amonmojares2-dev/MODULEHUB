<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "../database/dbconfig.php";

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login_form.html");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['name']);
    $id = trim($_POST['id']); 
    $course = trim($_POST['course']);
    $semester = trim($_POST['semester']);
    $date = trim($_POST['date']);
    $time = trim($_POST['time']);
    $appointment_datetime = $date . " " . $time;

    $subjects = $_POST['subject'];

    $sql_request = "INSERT INTO requests (STUDENT_NAME, S_ID, COURSE, SEMESTER, APPOINTMENT_DATETIME)
                    VALUES (?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql_request)) {
        mysqli_stmt_bind_param($stmt, "sssss", $name, $id, $course, $semester, $appointment_datetime);

        if (mysqli_stmt_execute($stmt)) {
            
            $request_id = mysqli_insert_id($conn);

            if (!empty($subjects)) {
                if (!is_array($subjects)) {
                    $subjects = [$subjects];
                }

                $sql_items = "INSERT INTO request_items (REQUEST_ID, SUBJECT_ID, S_ID)
                              VALUES (?, ?, ?)";

                if ($stmt_items = mysqli_prepare($conn, $sql_items)) {
                    foreach ($subjects as $subject_id) {
                        mysqli_stmt_bind_param($stmt_items, "isi", $request_id, $subject_id, $id);
                        mysqli_stmt_execute($stmt_items);
                    }
                    mysqli_stmt_close($stmt_items);
                }
            }

            echo "<script>
                alert('Request and items saved successfully!');
                window.location.href = 'student.php';
            </script>";

        } else {
            echo "<script>alert('Error saving request.');</script>";
        }

        mysqli_stmt_close($stmt);
    }

    mysqli_close($conn);
}
?>

<div id="popupRequest" class="popup">
  <div class="form-card">
    <a href="#" class="close">×</a>

    <form method="post" class="request-form">
      <h2>Module Request Form</h2>

      <label for="name">Name</label>
      <input type="text" id="name" name="name" placeholder="Enter your name" required>

      <label for="id">ID #</label>
      <input type="text" id="id" name="id" placeholder="Enter your ID" required>

      <div class="row">
        <div class="col">
          <label for="course">Course</label>
          <input type="text" id="course" name="course" placeholder="Enter course" required>
        </div>
        <div class="col">
          <label for="semester">Semester</label>
          <input type="text" id="semester" name="semester" placeholder="Enter semester" required>
        </div>
      </div>

      <label for="subject">Subject</label>
      <input type="text" id="subject" name="subject" placeholder="Enter subject" required>

      <div class="row">
        <div class="col">
          <label for="date">Date</label>
          <input type="date" id="date" name="date" required>
        </div>
        <div class="col">
          <label for="time">Time</label>
          <input type="time" id="time" name="time" required>
        </div>
      </div>

      <p class="note">
        <b>NOTE:</b> YOUR REQUEST MODULE IS ONLY HELD FOR 3 DAYS.<br>
        PLEASE PICK IT UP WITHIN 3 DAYS. IF YOU DON’T COLLECT YOUR MODULES
        WITHIN THIS PERIOD, YOU WILL NEED TO SUBMIT A NEW REQUEST.
      </p>
      <button type="submit" class="button">SUBMIT REQUEST</button>
    </form>
  </div>
</div>
