document.addEventListener('DOMContentLoaded', () => {
    const notifBtn = document.getElementById('notifBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const notifPopup = document.getElementById('notif-popup');
    const logoutPopup = document.getElementById('logout-popup');

    function openPopup(popup) {
        popup.classList.add('show');
    }

    function closePopup(popup) {
        popup.classList.remove('show');
    }

    notifBtn.addEventListener('click', (e) => {
        e.preventDefault();
        openPopup(notifPopup);
    });

    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        openPopup(logoutPopup);
    });

    document.querySelectorAll('.popup').forEach(popup => {
        popup.addEventListener('click', (e) => {
            if (e.target.classList.contains('popup') || e.target.classList.contains('close')) {
                closePopup(popup);
            }
        });
    });
});