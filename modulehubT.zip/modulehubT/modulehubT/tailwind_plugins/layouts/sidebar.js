/** @type {import('tailwindcss').Config} */
const plugin = require('tailwindcss/plugin');

module.exports = {
    content: [
        "./**/*.php",
        "./src/**/*.js",
        "./src/**/*.html"
    ],
    theme: {
        extend: {
            colors: {
                'sidebar-bg': '#2e8b57', // your green sidebar
            },
            spacing: {
                'sidebar-width': '175px',
            },
        },
    },
    plugins: [
        plugin(function({ addComponents }) {
            addComponents({
                '.pc-sidebar': {
                    '@apply fixed top-0 left-0 bottom-0 w-sidebar-width bg-sidebar-bg text-white flex flex-col justify-between p-4 transition-all duration-300': {},
                },
                '.pc-sidebar .upper': {
                    '@apply flex flex-col items-center gap-3': {},
                },
                '.pc-sidebar .lower': {
                    '@apply flex flex-col items-center gap-3 mt-auto': {},
                },
                '.pc-sidebar img': {
                    '@apply w-8 h-8 cursor-pointer hover:scale-110 transition': {},
                },
                '.popup': {
                    '@apply fixed inset-0 bg-black/50 flex items-center justify-center opacity-0 invisible transition duration-300': {},
                },
                '.popup.show': {
                    '@apply opacity-100 visible': {},
                },
                '.popup-content': {
                    '@apply bg-white rounded-xl p-6 min-w-[300px] text-center shadow-lg': {},
                },
                '.popup-content button': {
                    '@apply mt-4 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition': {},
                },
            });
        })
    ],
}