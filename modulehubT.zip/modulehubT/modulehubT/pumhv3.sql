-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2025 at 05:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pumhv3`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintb`
--

CREATE TABLE `admintb` (
  `ADMIN_ID` varchar(30) NOT NULL,
  `ADMIN_NAME` varchar(100) NOT NULL,
  `ADMIN_PASSWORD` varchar(255) NOT NULL,
  `ADMIN_EMAIL` varchar(100) NOT NULL,
  `ADMIN_POSITION` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admintb`
--

INSERT INTO `admintb` (`ADMIN_ID`, `ADMIN_NAME`, `ADMIN_PASSWORD`, `ADMIN_EMAIL`, `ADMIN_POSITION`) VALUES
('Admin1', 'Marvin Castillo', '$2y$10$SFucYmyZGyvUhtIf9lKav./NMeoATMHMOKkH3GmU65ZLWy/P70xsq', 'marvin.castillo@uni.edu.ph', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `archived_requested_items`
--

CREATE TABLE `archived_requested_items` (
  `ITEM_ID` int(11) NOT NULL,
  `REQUEST_ID` int(11) NOT NULL,
  `SUBJECT_ID` varchar(20) NOT NULL,
  `S_ID` int(11) DEFAULT NULL,
  `ARCHIVED_AT` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archived_requested_items`
--

INSERT INTO `archived_requested_items` (`ITEM_ID`, `REQUEST_ID`, `SUBJECT_ID`, `S_ID`, `ARCHIVED_AT`) VALUES
(12, 5, 'IT201', 1001, '2025-10-13 07:11:10');

-- --------------------------------------------------------

--
-- Table structure for table `archived_requests`
--

CREATE TABLE `archived_requests` (
  `REQUEST_ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `STUDENT_NAME` varchar(100) DEFAULT NULL,
  `REQUEST_TIME_DATE` timestamp NOT NULL DEFAULT current_timestamp(),
  `APPOINTMENT_DATE` date DEFAULT NULL,
  `SEMESTER` int(11) NOT NULL,
  `COURSE` varchar(100) NOT NULL,
  `REQUEST_STATUS` enum('APPROVED','PENDING','ON HOLD','EXPIRED') DEFAULT 'PENDING',
  `ARCHIVED_AT` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archived_requests`
--

INSERT INTO `archived_requests` (`REQUEST_ID`, `S_ID`, `STUDENT_NAME`, `REQUEST_TIME_DATE`, `APPOINTMENT_DATE`, `SEMESTER`, `COURSE`, `REQUEST_STATUS`, `ARCHIVED_AT`) VALUES
(5, 1001, 'Aljon M. Garcia', '2025-10-13 07:10:51', '2025-10-08', 2, 'BSIT - Bachelor of Science in Information Technology', 'APPROVED', '2025-10-13 07:11:10');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `COURSE_ID` int(11) NOT NULL,
  `COURSE_NAME` varchar(100) NOT NULL,
  `DEPT_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`COURSE_ID`, `COURSE_NAME`, `DEPT_ID`) VALUES
(101, 'BSIT - Bachelor of Science in Information Technology', 1),
(102, 'BSBA - Bachelor of Science in Business Administration', 5),
(103, 'BSCS - Bachelor of Science in Computer Science', 1),
(104, 'BSEd - Bachelor of Secondary Education', 2),
(105, 'BSN - Bachelor of Science in Nursing', 4),
(106, 'BSA - Bachelor of Science in Accountancy', 5),
(107, 'BSME - Bachelor of Science in Mechanical Engineering', 9),
(108, 'BSEE - Bachelor of Science in Electrical Engineering', 9),
(109, 'BSTM - Bachelor of Science in Tourism Management', 8),
(110, 'BSHM - Bachelor of Science in Hospitality Management', 8),
(111, 'SHS - ICT (Information and Communications Technology)', 3),
(112, 'SHS - ABM (Accountancy, Business, and Management)', 3),
(113, 'SHS - STEM (Science, Technology, Engineering, and Mathematics)', 3),
(114, 'SHS - HUMSS (Humanities and Social Sciences)', 3),
(115, 'SHS – TVL - COOKERY', 3);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DEPT_ID` int(11) NOT NULL,
  `DEPT_NAME` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DEPT_ID`, `DEPT_NAME`) VALUES
(1, 'CITE'),
(2, 'CAS'),
(3, 'SHS'),
(4, 'CAHS'),
(5, 'CMA'),
(6, 'BE'),
(7, 'CCJE'),
(8, 'CHMT'),
(9, 'CEA');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `REQUEST_ID` int(11) NOT NULL,
  `S_ID` int(11) DEFAULT NULL,
  `STUDENT_NAME` varchar(100) DEFAULT NULL,
  `REQUEST_TIME_DATE` timestamp NOT NULL DEFAULT current_timestamp(),
  `APPOINTMENT_DATE` date DEFAULT NULL,
  `SEMESTER` int(11) NOT NULL,
  `COURSE` varchar(100) NOT NULL,
  `REQUEST_STATUS` enum('APPROVED','PENDING','ON HOLD','EXPIRED') DEFAULT 'PENDING'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_items`
--

CREATE TABLE `request_items` (
  `ITEM_ID` int(11) NOT NULL,
  `REQUEST_ID` int(11) NOT NULL,
  `SUBJECT_ID` varchar(20) NOT NULL,
  `S_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `S_ID` int(11) NOT NULL,
  `F_NAME` varchar(100) NOT NULL,
  `M_I` varchar(5) DEFAULT NULL,
  `L_NAME` varchar(100) NOT NULL,
  `S_PASSWORD` varchar(255) NOT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `S_NUMBER` varchar(11) NOT NULL,
  `COURSE_ID` int(11) DEFAULT NULL,
  `YEAR_LEVEL` varchar(20) NOT NULL,
  `ROLE` varchar(20) NOT NULL DEFAULT 'students'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`S_ID`, `F_NAME`, `M_I`, `L_NAME`, `S_PASSWORD`, `EMAIL`, `S_NUMBER`, `COURSE_ID`, `YEAR_LEVEL`, `ROLE`) VALUES
(1001, 'Aljon', 'M', 'Garcia', '$2y$10$S7iffZkXVOojJly3uRzCe.YohOgWU.sWnOSZ/K6DVG.35Dk1OrUVO', 'aljon.garcia@uni.edu.ph', '09171234567', 101, '3', 'Student'),
(1002, 'Bianca', 'L', 'Reyes', '$2y$10$IUboUe0XIBHafvdsYXWciubZ.tSUZ.2T/1J.C/qTRKEo2zIlkviNa', 'bianca.reyes@uni.edu.ph', '09281234567', 102, '2', 'Student'),
(1003, 'Carlo', 'J', 'Mendoza', '$2y$10$tRleagy7E1jXGGmeyIsyae5VAEG5BAhTo5V8fJT4TDkGo9OPC8YS6', 'carlo.mendoza@uni.edu.ph', '09391234567', 101, '4', 'Student'),
(1004, 'Denise', 'A', 'Cruz', '$2y$10$fUjJquqe60H.Viq/0K5B8OaMnILexIEla/jNJ3jTyKqZIDfjSGo0W', 'denise.cruz@uni.edu.ph', '09481234567', 103, '1', 'Student'),
(1005, 'Ethan', 'R', 'Santos', '$2y$10$haVVqVkFMcbqa4UZTnIOSu4NN5PxaZ0k/fZ.H2Qhr0jHxoO1Mnuo6', 'ethan.santos@uni.edu.ph', '09571234567', 109, '2', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SUBJECT_ID` varchar(20) NOT NULL,
  `SUBJECT_NAME` varchar(100) NOT NULL,
  `UNITS` int(11) NOT NULL,
  `COURSE_ID` int(11) DEFAULT NULL,
  `YEAR_LEVEL` int(11) DEFAULT NULL,
  `SUBJECT_SEMESTER` enum('1','2','Summer') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`SUBJECT_ID`, `SUBJECT_NAME`, `UNITS`, `COURSE_ID`, `YEAR_LEVEL`, `SUBJECT_SEMESTER`) VALUES
('ABM101', 'Applied Economics', 3, 112, 11, '1'),
('ABM102', 'Business Ethics and Social Responsibility', 3, 112, 11, '2'),
('ABM201', 'Fundamentals of Accounting', 3, 112, 12, '1'),
('ABM202', 'Organization and Management', 3, 112, 12, '2'),
('ABM301', 'Business Finance', 3, 112, 12, '2'),
('ACC101', 'Basic Accounting', 3, 106, 1, '1'),
('ACC102', 'Business Law and Taxation', 3, 106, 1, '2'),
('ACC201', 'Intermediate Accounting 1', 3, 106, 2, '1'),
('ACC202', 'Cost Accounting', 3, 106, 2, '2'),
('ACC301', 'Auditing Theory', 3, 106, 3, '1'),
('BA101', 'Principles of Management', 3, 102, 1, '1'),
('BA102', 'Business Mathematics', 3, 102, 1, '2'),
('BA201', 'Financial Accounting 1', 3, 102, 2, '1'),
('BA202', 'Marketing Management', 3, 102, 2, '2'),
('BA301', 'Business Law', 3, 102, 3, '1'),
('CS101', 'Introduction to Computer Science', 3, 103, 1, '1'),
('CS102', 'Discrete Mathematics', 3, 103, 1, '2'),
('CS201', 'Object-Oriented Programming', 3, 103, 2, '1'),
('CS202', 'Computer Organization and Architecture', 3, 103, 2, '2'),
('CS301', 'Software Engineering', 3, 103, 3, '1'),
('ED101', 'Foundations of Education', 3, 104, 1, '1'),
('ED102', 'Child and Adolescent Development', 3, 104, 1, '2'),
('ED201', 'Facilitating Learning', 3, 104, 2, '1'),
('ED202', 'Curriculum Development', 3, 104, 2, '2'),
('ED301', 'Assessment of Student Learning', 3, 104, 3, '1'),
('EE101', 'Electrical Circuits 1', 3, 108, 1, '1'),
('EE102', 'Electromagnetics', 3, 108, 1, '2'),
('EE201', 'Electrical Circuits 2', 3, 108, 2, '1'),
('EE202', 'Power Systems Analysis', 3, 108, 2, '2'),
('EE301', 'Electrical Machines', 3, 108, 3, '1'),
('HM101', 'Introduction to Hospitality Management', 3, 110, 1, '1'),
('HM102', 'Food and Beverage Service', 3, 110, 1, '2'),
('HM201', 'Front Office Operations', 3, 110, 2, '1'),
('HM202', 'Housekeeping Management', 3, 110, 2, '2'),
('HM301', 'Event Management', 3, 110, 3, '1'),
('HUM101', 'Creative Writing', 3, 114, 11, '1'),
('HUM102', 'World Religions and Belief Systems', 3, 114, 11, '2'),
('HUM201', 'Philippine Politics and Governance', 3, 114, 12, '1'),
('HUM202', 'Community Engagement, Solidarity, and Citizenship', 3, 114, 12, '2'),
('HUM301', 'Creative Nonfiction', 3, 114, 12, '2'),
('ICT101', 'Computer Systems Servicing', 3, 111, 11, '1'),
('ICT102', 'Programming Fundamentals', 3, 111, 11, '2'),
('ICT201', 'Web Development', 3, 111, 12, '1'),
('ICT202', 'Networking Fundamentals', 3, 111, 12, '2'),
('ICT301', 'Capstone Project', 3, 111, 12, '2'),
('IT101', 'Introduction to Information Technology', 3, 101, 1, '1'),
('IT102', 'Computer Programming 1', 3, 101, 1, '2'),
('IT201', 'Data Structures and Algorithms', 3, 101, 2, '1'),
('IT202', 'Database Management Systems', 3, 101, 2, '2'),
('IT301', 'Operating Systems', 3, 101, 3, '1'),
('ME101', 'Engineering Drawing', 3, 107, 1, '1'),
('ME102', 'Engineering Mechanics', 3, 107, 1, '2'),
('ME201', 'Thermodynamics', 3, 107, 2, '1'),
('ME202', 'Fluid Mechanics', 3, 107, 2, '2'),
('ME301', 'Machine Design', 3, 107, 3, '1'),
('NUR101', 'Fundamentals of Nursing Practice', 3, 105, 1, '1'),
('NUR102', 'Anatomy and Physiology', 3, 105, 1, '2'),
('NUR201', 'Health Assessment', 3, 105, 2, '1'),
('NUR202', 'Microbiology and Parasitology', 3, 105, 2, '2'),
('NUR301', 'Community Health Nursing', 3, 105, 3, '1'),
('STEM101', 'General Biology 1', 3, 113, 11, '1'),
('STEM102', 'General Chemistry 1', 3, 113, 11, '2'),
('STEM201', 'General Physics 1', 3, 113, 12, '1'),
('STEM202', 'Pre-Calculus', 3, 113, 11, '1'),
('STEM301', 'General Biology 2', 3, 113, 12, '2'),
('TM101', 'Introduction to Tourism Management', 3, 109, 1, '1'),
('TM102', 'Tourism Planning and Development', 3, 109, 1, '2'),
('TM201', 'Hospitality Operations', 3, 109, 2, '1'),
('TM202', 'Tourism Marketing', 3, 109, 2, '2'),
('TM301', 'Sustainable Tourism', 3, 109, 3, '1'),
('TVL101', 'Cookery 1: Fundamentals', 3, 115, 11, '1'),
('TVL102', 'Cookery 2: Food Preparation', 3, 115, 11, '2'),
('TVL201', 'Cookery 3: Kitchen Management', 3, 115, 12, '1'),
('TVL202', 'Cookery 4: International Cuisine', 3, 115, 12, '2'),
('TVL301', 'Cookery 5: Catering Services', 3, 115, 12, '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintb`
--
ALTER TABLE `admintb`
  ADD PRIMARY KEY (`ADMIN_ID`),
  ADD UNIQUE KEY `ADMIN_PASSWORD` (`ADMIN_PASSWORD`),
  ADD UNIQUE KEY `ADMIN_EMAIL` (`ADMIN_EMAIL`);

--
-- Indexes for table `archived_requested_items`
--
ALTER TABLE `archived_requested_items`
  ADD PRIMARY KEY (`ITEM_ID`),
  ADD UNIQUE KEY `unique_student_subject` (`S_ID`,`SUBJECT_ID`),
  ADD KEY `REQUEST_ID` (`REQUEST_ID`),
  ADD KEY `SUBJECT_ID` (`SUBJECT_ID`);

--
-- Indexes for table `archived_requests`
--
ALTER TABLE `archived_requests`
  ADD PRIMARY KEY (`REQUEST_ID`),
  ADD KEY `S_ID` (`S_ID`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`COURSE_ID`),
  ADD KEY `DEPT_ID` (`DEPT_ID`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DEPT_ID`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`REQUEST_ID`),
  ADD KEY `S_ID` (`S_ID`);

--
-- Indexes for table `request_items`
--
ALTER TABLE `request_items`
  ADD PRIMARY KEY (`ITEM_ID`),
  ADD UNIQUE KEY `S_ID` (`S_ID`,`SUBJECT_ID`),
  ADD KEY `SUBJECT_ID` (`SUBJECT_ID`),
  ADD KEY `fk_request_items_request` (`REQUEST_ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`S_ID`),
  ADD UNIQUE KEY `S_NUMBER` (`S_NUMBER`),
  ADD UNIQUE KEY `S_NUMBER_2` (`S_NUMBER`),
  ADD UNIQUE KEY `S_PASSWORD` (`S_PASSWORD`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD KEY `COURSE_ID` (`COURSE_ID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SUBJECT_ID`),
  ADD KEY `COURSE_ID` (`COURSE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archived_requested_items`
--
ALTER TABLE `archived_requested_items`
  MODIFY `ITEM_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `archived_requests`
--
ALTER TABLE `archived_requests`
  MODIFY `REQUEST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `REQUEST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `request_items`
--
ALTER TABLE `request_items`
  MODIFY `ITEM_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `archived_requested_items`
--
ALTER TABLE `archived_requested_items`
  ADD CONSTRAINT `archived_requested_items_ibfk_1` FOREIGN KEY (`REQUEST_ID`) REFERENCES `archived_requests` (`REQUEST_ID`),
  ADD CONSTRAINT `archived_requested_items_ibfk_2` FOREIGN KEY (`SUBJECT_ID`) REFERENCES `subjects` (`SUBJECT_ID`),
  ADD CONSTRAINT `archived_requested_items_ibfk_3` FOREIGN KEY (`S_ID`) REFERENCES `students` (`S_ID`);

--
-- Constraints for table `archived_requests`
--
ALTER TABLE `archived_requests`
  ADD CONSTRAINT `archived_requests_ibfk_1` FOREIGN KEY (`S_ID`) REFERENCES `students` (`S_ID`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`DEPT_ID`) REFERENCES `departments` (`DEPT_ID`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`S_ID`) REFERENCES `students` (`S_ID`);

--
-- Constraints for table `request_items`
--
ALTER TABLE `request_items`
  ADD CONSTRAINT `fk_request_items_request` FOREIGN KEY (`REQUEST_ID`) REFERENCES `requests` (`REQUEST_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `request_items_ibfk_1` FOREIGN KEY (`REQUEST_ID`) REFERENCES `requests` (`REQUEST_ID`),
  ADD CONSTRAINT `request_items_ibfk_2` FOREIGN KEY (`SUBJECT_ID`) REFERENCES `subjects` (`SUBJECT_ID`),
  ADD CONSTRAINT `request_items_ibfk_3` FOREIGN KEY (`S_ID`) REFERENCES `students` (`S_ID`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `courses` (`COURSE_ID`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `courses` (`COURSE_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
