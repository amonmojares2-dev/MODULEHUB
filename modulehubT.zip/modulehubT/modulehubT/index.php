<?php
session_start();
require_once "dist/database/db/config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
 
    // Check admin table
    $sql_admin = "SELECT ADMIN_ID, ADMIN_NAME, ADMIN_PASSWORD, ADMIN_EMAIL, ADMIN_POSITION FROM admintb WHERE ADMIN_ID = ?";
    $stmt_admin = mysqli_prepare($conn, $sql_admin);
    mysqli_stmt_bind_param($stmt_admin, "s", $username);

    if (mysqli_stmt_execute($stmt_admin)) {
        mysqli_stmt_store_result($stmt_admin);

        if (mysqli_stmt_num_rows($stmt_admin) == 1) {
            mysqli_stmt_bind_result($stmt_admin, $admin_id, $admin_name, $admin_password, $admin_email, $admin_position);
            mysqli_stmt_fetch($stmt_admin);

            if (password_verify($password, $admin_password)) {
                $_SESSION["loggedin"] = true;
                $_SESSION["admin_id"] = $admin_id;
                $_SESSION["username"] = $username;
                $_SESSION["adminname"] = $admin_name;
                $_SESSION["role"] = $admin_position;

                header("Location: dist/admin/ad-dashboard.php");
                exit;
            } else {
                echo "<script>
                    alert('Your email or password is incorrect.');
                    window.location.href='index.php';
                </script>"; 
                exit;
            }
        }
        mysqli_stmt_close($stmt_admin);
    }

    // Check students table
    $sql = "SELECT S_ID, F_NAME, M_I, L_NAME, S_PASSWORD, EMAIL, S_NUMBER, COURSE_ID, YEAR_LEVEL, ROLE FROM students WHERE S_ID = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $username);

    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) == 1) {
            mysqli_stmt_bind_result($stmt, $id, $fname, $mi, $lname, $hashed_password, $email, $s_number, $course_id, $year_level, $role);
            mysqli_stmt_fetch($stmt);

            if (password_verify($password, $hashed_password)) {

                $sql_course = "SELECT COURSE_NAME FROM courses WHERE COURSE_ID = ?";
                $stmt_course = mysqli_prepare($conn, $sql_course);
                mysqli_stmt_bind_param($stmt_course, "s", $course_id); 
                mysqli_stmt_execute($stmt_course);
                mysqli_stmt_store_result($stmt_course);

                if (mysqli_stmt_num_rows($stmt_course) == 1) {
                    mysqli_stmt_bind_result($stmt_course, $course_name); 
                    mysqli_stmt_fetch($stmt_course);
                    $_SESSION["course_name"] = $course_name;
                } else {
                    $_SESSION["course_name"] = null; 
                }

                mysqli_stmt_close($stmt_course);

                $_SESSION["loggedin"] = true;
                $_SESSION["s_id"] = $id;
                $_SESSION["username"] = $username;
                $_SESSION["name"] = "{$fname} {$mi}. {$lname}";
                $_SESSION["role"] = $role;
                $_SESSION["email"] = $email;
                $_SESSION["course_id"] = $course_id;
                $_SESSION["course_name"] = $course_name;

                header("Location: dist/student/student.php");
                exit;
            } else {
                 echo "<script>
                    alert('Your email or password is incorrect.');
                    window.location.href='index.php';
                </script>"; 
                exit;
            }
        } else {
            echo "No account found with that ID.";
        }
    mysqli_stmt_close($stmt);
    } else {
        echo "Oops! Something went wrong.";
    }
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHINMA UPang ModuleHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Optional: fade-in animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            animation: fadeIn 0.8s ease-in-out;
        }
    </style>
</head>

<body class="h-screen bg-[#E0F2F1] ">


    <!-- Main Content -->
    <div class="relative z-10 flex flex-col lg:flex-row items-center justify-center h-full px-6 sm:px-10">
        
        <!-- Left Text Section -->
        <div class="text-white max-w-xl mb-12 lg:mb-0 fade-in text-center lg:text-left md:pr-40">
            <h1 class="text-4xl sm:text-5xl md:text-6xl text-green-800  font-extrabold drop-shadow-lg mb-4">
                ModuleHub
            </h1>
            <p class="text-lg sm:text-xl text-green-800 italic">
                “Simplifying access, amplifying learning”
            </p>
        </div>

        <!-- Login Card -->
        <div class="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl shadow-2xl p-8 sm:p-10 w-full max-w-sm fade-in">
            
            <!-- Logo -->
            <div class="flex justify-center mb-6">
                <img src="../../../images/Picture1.png" alt="University Logo" class="w-24 h-24 object-contain">
            </div>

            <!-- Login Form -->
            <form action="index.php" method="post" class="space-y-5">
                <div>
                    <label class="block text-green font-medium mb-2 text-sm">Username</label>
                    <input type="text" name="username" required
                           class="w-full px-4 py-2 rounded-lg bg-white/80 focus:bg-white focus:ring-2 focus:ring-green-500 outline-none text-green-800 placeholder-gray-400">
                </div>
                <div>
                    <label class="block text-green font-medium mb-2 text-sm">Password</label>
                    <input type="password" name="password" required
                           class="w-full px-4 py-2 rounded-lg bg-white/80 focus:bg-white focus:ring-2 focus:ring-green-500 outline-none text-green-800 placeholder-gray-400">
                </div>

                <button type="submit"
                        class="w-full py-3 bg-green-600 hover:bg-green-700 transition text-white font-semibold rounded-lg shadow-lg">
                    LOGIN
                </button>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="absolute bottom-3 left-0 w-full text-center text-green text-xs ">
        © 2025 PHINMA UPang ModuleHub • All Rights Reserved
    </footer>
</body>
</html>
