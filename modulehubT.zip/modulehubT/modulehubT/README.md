# README FILE OF PHINMA UPang Module Hub

This file contains the documentation of PUMH.

## 📖 Overview
The **PHINMA UPang Module Hub (PUMH)** is a web-based system that aims to reduce the waiting time of students when collecting their modules and to speed up the distribution process.

## ⚙️ Requirements
- PHP >= 7.4
- MySQL >= 5.7
- Web server (Apache/Nginx or use XAMPP/Laragon)
- Composer (if using PHP dependencies)