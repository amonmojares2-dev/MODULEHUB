<?php
require_once "dist/database/db/config.php";

$sql = "SELECT S_ID, S_PASSWORD FROM students";
$result = mysqli_query($conn, $sql);

$updatedCount = 0;

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['S_ID'];
        $plain = $row['S_PASSWORD'];

        if (strpos($plain, '$2y$') !== 0) {
            $hashed = password_hash($plain, PASSWORD_DEFAULT);

            $update = "UPDATE students SET S_PASSWORD = ? WHERE S_ID = ?";
            $stmt = mysqli_prepare($conn, $update);
            mysqli_stmt_bind_param($stmt, "si", $hashed, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            $updatedCount++;
        }
    }
    echo "✅ $updatedCount password(s) have been securely hashed!";
} else {
    echo "⚠️ No student records found.";
}

$sql = "SELECT ADMIN_ID, ADMIN_PASSWORD FROM admintb";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['ADMIN_ID'];
    $plain = $row['ADMIN_PASSWORD'];

    if (strpos($plain, '$2y$') !== 0) {
        $hashed = password_hash($plain, PASSWORD_DEFAULT);

        $update = "UPDATE adminTB SET ADMIN_PASSWORD = ? WHERE ADMIN_ID = ?";
        $stmt = mysqli_prepare($conn, $update);
        mysqli_stmt_bind_param($stmt, "ss", $hashed, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

mysqli_close($conn);
echo "All plain-text passwords have been securely hashed!";
?>
